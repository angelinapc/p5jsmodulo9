let palavra //criando a variável "palavra"

function setup() { //função "setup"
  createCanvas(400, 400); //criando o cenário
  
  palavra = palavraAleatoria() //criando a função "palavra"
  
}

  function palavraAleatoria() { //função "palavraAleatoria"
  let palavras = ["Amarelo", "Rosa", "Branco"]; //criando as palavras
  return random(palavras); //retornando a variável "palavra" e "sorteando" as palavras
}

function inicializaCores() {
  background("white"); //cor do fundo
  fill("black"); //cor das letras
  textSize(60); //tamanho do texto
  textAlign(CENTER, CENTER); //função para alinhar o texto no centro
} //criando a função "inicializaCores"

function palavraParcial(minimo, maximo) { //definindo a função "palavraParcial"
  let quantidade = map(mouseX, minimo, maximo, 1, palavra.length); //quantidade de letras que serão utilizadas, sempre vai iniciar com o "A"
  let parcial = palavra.substring(0, quantidade); //separando as letras
  return parcial; //retornando "parcial"
  }

function draw() {
  inicializaCores()

  let texto = palavraParcial(0, width); //definindo a variável "text" (= palavraParcial)
  text(texto, 200, 200); //posição do texto
    
  }
  
  function LugareBacanasParaPassear(DiaDaSemana, Bairro){
  } //mostrando que é possível criar novas funções em seu projeto de acordo com suas preferências